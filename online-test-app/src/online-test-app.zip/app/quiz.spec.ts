import { Quiz } from './online-quiz/quiz';

describe('Quiz', () => {
  it('should create an instance', () => {
    expect(new Quiz()).toBeTruthy();
  });
});
